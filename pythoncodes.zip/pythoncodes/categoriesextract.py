import sqlite3

connection = sqlite3.connect('rXivPapers.db')
cursor = connection.cursor()
categories = []
sql = "SELECT categories FROM Paper"
cursor.execute(sql, categories)
rows = cursor.fetchall()
for row in rows:
    categories.append(row)
# Create an empty set to store unique categories
unique_categories = set()
for category_tuple in categories:
    # Remove double quotes and split the string into individual categories
    categories = category_tuple[0].replace('"', '').split()
    for category in categories:
        unique_categories.add(category)

# Convert the set to a list if needed
unique_categories_list = list(unique_categories)

cursor.execute("CREATE TEMP TABLE UniqueCategories (Category TEXT)")
# Insert the unique categories into the temporary table
for category in unique_categories:
    cursor.execute("INSERT INTO UniqueCategories (Category) VALUES (?)", (category,))
cursor.execute("CREATE VIEW UniqueCategoriesView AS SELECT * FROM UniqueCategories")

connection.commit()
connection.close()


