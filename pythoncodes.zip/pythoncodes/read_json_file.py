import sqlite3
import json
import re

# Create a SQLite database and a cursor to execute SQL commands
conn = sqlite3.connect('rXivPapers.db')
cursor = conn.cursor()

Author_id=1
# Open and read the JSON file
with open('arXiv21.json', 'r', encoding="utf-8") as json_file:
    for line in json_file:
        # Parse JSON data
        paper = json.loads(line)
        paper_id = paper['id']
        lst_author = json.dumps(paper['authors'])  # Convert authors to a JSON string
        submitter = paper['submitter']
        title = paper['title']
        categories = json.dumps(paper['categories'])  # Convert categories to a JSON string
        last_update = paper['last_update']
        cited = paper['cited']

        cursor.execute('''INSERT INTO Paper (paper_id,title, lastupdate, categories) VALUES (?, ?, ?, ?) ''', (paper_id, title, last_update, categories))
        cursor.execute('''INSERT INTO Cite (paper_id,Cite) VALUES (?,?) ''', (paper_id,cited))

        matches = re.findall(r'"([^"]+)"', lst_author)
        M=False
        for full_name in matches:

            parts = full_name.split()  # Split the full name using whitespace as the separator
            if len(parts) == 2:
                last_name,first_name = parts
                cursor.execute('''INSERT INTO Author (Author_id,FNAME, LNAME) VALUES (?, ?, ?) ''', (Author_id,first_name, last_name))
                cursor.execute('''INSERT INTO Writer (paper_id,Author_id) VALUES (?, ?) ''', (paper_id, Author_id))
               # Author_id = Author_id + 1
            else:
                # Handle cases where the name does not follow the expected format
                # You can choose to skip or handle these cases differently
                parts=full_name.split()
                last_name=parts[0]
                delimiter=' '
                first_name=delimiter.join(parts[0:])
                cursor.execute('''INSERT INTO Author (Author_id,FNAME, LNAME) VALUES (?, ?, ?) ''', (Author_id,first_name, last_name))
                cursor.execute('''INSERT INTO Writer (paper_id,Author_id) VALUES (?, ?) ''', (paper_id, Author_id))
                #Author_id = Author_id + 1
            if M==False:
                        parts=submitter.split()   
                        if len(parts) == 2:
                            slast_name,sfirst_name = parts
                        else:
                            parts=submitter.split()
                            slast_name=parts[0]
                            delimiter=' '
                            sfirst_name=delimiter.join(parts[0:])
                        if (first_name == sfirst_name) and (last_name==slast_name) :
                              cursor.execute('''INSERT INTO Submit (paper_id,Author_id) VALUES (?, ?) ''', (paper_id, Author_id))
                              M=True
            Author_id = Author_id + 1


conn.commit()
# Close the database connection
conn.close()
